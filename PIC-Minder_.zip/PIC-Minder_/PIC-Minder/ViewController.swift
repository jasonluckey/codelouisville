//
//  ViewController.swift
//  PIC-Minder
//
//  Created by user on 7/15/17.
//  Copyright © 2017 taterbait. All rights reserved.
//

import UIKit
import CoreData

var titles:[String] = []
var subtitles:[String] = []
var pictures:[String] = []

var thisItem = 0

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var myTableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return titles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = titles[indexPath.row]
        cell.detailTextLabel?.text = subtitles[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            thisItem = indexPath.row
            deleteThis()
            getThis()
        }
    }
    @IBAction func addItem(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getThis()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //I don't want this to rotate
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    //Retrieve Data Function
    func getThis(){
        //Refer to AppDelegate
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //Create manager that allows work with CoreData
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Reminder")
        //Do it or complain
        do {
            let results = try context.fetch(request)
            //check if there is data
            if results.count > 0
            {
                titles.removeAll()
                subtitles.removeAll()
                pictures.removeAll()
                
                for result in results as! [NSManagedObject]
                {
                    if let myTitle = result.value(forKey: "title") as? String
                    {
                        titles.append(myTitle)
                    }
                    else
                    {
                        titles.append(" ")
                    }
                    if let mySubTitle = result.value(forKey: "subtitle") as? String
                    {
                        subtitles.append(mySubTitle)
                    }
                    else
                    {
                        subtitles.append(" ")
                    }
                    if let myPicture = result.value(forKey: "picture") as? String
                    {
                        pictures.append(myPicture)
                    }
                    else
                    {
                        pictures.append(" ")
                    }
                }
            }
        myTableView.reloadData()
        }
        catch {
        }
    }
    //Delete Data Function
    func deleteThis()
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "ToDo")
        
        do
        {
            let results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results as! [NSManagedObject]
                {
                    if let myTitle = result.value(forKey: "title") as? String
                    {
                        if myTitle == titles[thisItem]
                        {
                            context.delete(result)
                            
                            do
                            {
                                try context.save()
                            }
                            catch
                            {
                                
                            }
                        }
                    }
                }
            }
        }
        catch
        {
            
        }
    }
    //Save Data Function
    func saveThis(title: String, subtitle: String) {
        //func saveThis(title: String, subtitle: String, picture: String) {
        //Refer to AppDelegate
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //Create manager that allows work with CoreData
        let context = appDelegate.persistentContainer.viewContext
        let newItem = NSEntityDescription.insertNewObject(forEntityName: "Reminder", into: context)
        newItem.setValue(title, forKey: "title")
        newItem.setValue(subtitle, forKey: "subtitle")
        //newItem.setValue(picture, forKey: "picture")
        
        //Do it or complain
        do {
            try context.save()
            print ("SAVED")
        }
        catch {
            print ("There was an error")
        }
    }
    
}
