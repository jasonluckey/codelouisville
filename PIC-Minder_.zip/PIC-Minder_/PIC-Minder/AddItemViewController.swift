//
//  AddItemViewController.swift
//  PIC-Minder
//
//  Created by user on 7/15/17.
//  Copyright © 2017 taterbait. All rights reserved.
//


import UIKit
import CoreData
import EventKit


class AddItemViewController: UIViewController {
    
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtNotes: UITextField!
    @IBOutlet weak var setTime: UIDatePicker!
    /*@IBAction func takePic(_ sender: Any) {
        //Use the Camera Storyboard
        let storyboard = UIStoryboard(name: "Camera", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "CameraViewController") as UIViewController
        self.present(controller, animated: true, completion: nil)
    }*/
    
    @IBAction func saveItem(_ sender: Any) {
        if txtTitle.text != "" && txtNotes.text != ""
        {
            saveThis(title: txtTitle.text!, subtitle: txtNotes.text!)
            txtTitle.text = ""
            txtNotes.text = ""
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //I don't want this to rotate
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    //Save Data Function
    func saveThis(title: String, subtitle: String) {
    //func saveThis(title: String, subtitle: String, picture: String) {
        //Refer to AppDelegate
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        //Create manager that allows work with CoreData
        let context = appDelegate.persistentContainer.viewContext
        let newItem = NSEntityDescription.insertNewObject(forEntityName: "Reminder", into: context)
        newItem.setValue(title, forKey: "title")
        newItem.setValue(subtitle, forKey: "subtitle")
        //newItem.setValue(picture, forKey: "picture")
        
        //Do it or complain
        do {
            try context.save()
            print ("SAVED")
        }
        catch {
            print ("There was an error")
        }
    }
    
    
}

